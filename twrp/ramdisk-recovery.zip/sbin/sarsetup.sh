#!/sbin/sh

# Set ro.twrp.sar to false
resetprop "ro.twrp.sar" "false"
